#*****************************************************
# Author : Laltu Sardar
# Indian Statistical Institute, Kolkata
# Supervisor: Dr. Sushmita Ruj
# **************Instructions************************
# installed ReadPst to extract files
# 1. Data should be in the folder dataset
# 2. extractedDataSet folder should be created in the folder where MakeFile is
# 3. current_path sould be edited
#*****************************************************


import os
current_path = "/home/laltu/Desktop/dataFilter"
source_dir = "dataset"
dst_dir = "extractedDataSet"
listOfFiles = os.listdir(current_path+"/"+source_dir)
noOfFiles = len(listOfFiles)
for i in range(noOfFiles):
    fileName = listOfFiles[i]
    os.system("readpst -M "+source_dir+"/"+fileName + " -o "+dst_dir)
    print (".......................................................")
print ("Success")
